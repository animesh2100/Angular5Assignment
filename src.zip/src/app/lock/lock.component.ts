import { Component, OnInit } from '@angular/core';
import {MilestoneService} from './../milestone.service';

@Component({
  selector: 'app-lock',
  templateUrl: './lock.component.html',
  styleUrls: ['./lock.component.css']
})
export class LockComponent implements OnInit {

  constructor(private milestoneService: MilestoneService) { } // subscribe to MilestoneService

  currentMilestone = 0; // holds current milestone reached at a given point of time
  prefixNum = [0, 0, 0]; // used for lock image file naming compliance
  postfixNum = 1; // used for lock image file naming compliance
  imageNumber = ''; // holds the image number eg format 0001
  dialStoppage = { '1': 112, '2': 252, '3': 456}; // denotes the image number where the lock rotates for a milestone completion

  ngOnInit() {
    this.milestoneService.currentMilestone.subscribe(mileStoneNum => {
      this.turnLockDial(mileStoneNum); // turn lock dial as the milestone changes
      this.currentMilestone = mileStoneNum;
    });
    this.imageNumber = this.generateImageNum(this.postfixNum); // initialize image
  }

  /*
  ** generates image number in a format 0001, 0010 etc
  */
  generateImageNum (postFix) {
   if ( ( postFix.toString().length + this.prefixNum.length ) > 4) {
    this.prefixNum.pop();
    return this.prefixNum.join('') + postFix;
   } else {
     return this.prefixNum.join('') + postFix;
   }
  }


  /*
  ** turn the lock dial to a specified image number depending upon milestone reached
  */
  turnLockDial(pCurrentMilestone) {
    if (pCurrentMilestone > 0) {
      const interval = setInterval(() => {
        this.postfixNum ++;
        this.imageNumber = this.generateImageNum(this.postfixNum + 70);
         console.log(this.dialStoppage[pCurrentMilestone] + '===' +  this.postfixNum);
        if (this.dialStoppage[pCurrentMilestone] === this.postfixNum + 70) {
          // console.log('stop');
          clearInterval(interval);
          return;
        }
      }, 50); // animation speed is 50
    } else {
      // reset lock
      this.imageNumber = '0001';
    }
  }
}
