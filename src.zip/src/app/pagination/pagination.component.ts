import { Component, OnInit } from '@angular/core';
import {MilestoneService} from './../milestone.service';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css']
})
export class PaginationComponent implements OnInit {

  constructor(private milestoneService: MilestoneService) { }
  currentMilestone = 0;
  ngOnInit() {
    this.milestoneService.currentMilestone.subscribe(mileStoneNum => this.currentMilestone = mileStoneNum);
  }

}
