/*
 QuestionDataService will provide question and answers data and also maintain current index ( index number of question array)
 index will be changed by answers componenent from time to time as answers get completed
 A componenet subscribing to QuestionDataService will get question data as well as current index,
 which it can use to goto specific question set
 */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuestionDataService {

  private curIndexSource = new BehaviorSubject(0);
  currentIndex = this.curIndexSource.asObservable();

  constructor() { }

  // updates the index of question & ans set array
  changeIndex(indexVal: number) {
    this.curIndexSource.next(indexVal);
  }

  // returns question and answers json data
  getQuestionData() {
    return [
      {
        q: 'The little lost sheep are in ____________!',
        o: [
          'partner',
          'special',
          'danger',
          'splendid'
        ],
        a: 'danger'
      },
      {
        q: 'Meg is my _____________ in math.',
        o: [
          'danger',
          'partner',
          'splendid',
          'special'
        ],
        a: 'partner'
      },
      {
        q: 'The queen lives in a _____________ castle.',
        o: [
          'partner',
          'splendid',
          'danger',
          'special'
        ],
        a: 'splendid'
      },
      {
        q: 'My _____________ and I will work together as a team.',
        o: [
          'special',
          'danger',
          'partner',
          'splendid'
        ],
        a: 'partner'
      },
      {
        q: 'That hat is _____________ because Gran gave it to me.',
        o: [
          'danger',
          'partner',
          'special',
          'splendid'
        ],
        a: 'special'
      },
      {
        q: 'Small fish may face _____________ in the big sea.',
        o: [
          'splendid',
          'special',
          'danger',
          'partner'
        ],
        a: 'danger'
      },
      {
        q: 'I thanked my host for a _____________ meal.',
        o: [
          'splendid',
          'danger',
          'special',
          'partner'
        ],
        a: 'splendid'
      },
      {
        q: 'He will get _____________ glasses to help him see.',
        o: [
          'danger',
          'special',
          'partner',
          'splendid'
        ],
        a: 'special'
      }
    ];
  }
}
