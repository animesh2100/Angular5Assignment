import { QuestionDataService } from './../question-data.service';
import { MilestoneService } from './../milestone.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-answers',
  templateUrl: './answers.component.html',
  styleUrls: ['./answers.component.css']
})
export class AnswersComponent implements OnInit {

  questions = []; // question data
  displayIndex = 0; // index of question data array
  displaySet = []; // currently displayed question data which is at displayIndex
  isCorrectAns = false; // holds boolean value ie if an answer is correct
  retryCount = 0; // number of retrys  count
  correctAns = ''; // holds the value of correct answer at a given point of time
  correctAnsCount = 0; // holds overall corretly answered count at the given time
  disableSubmit = true; // controls the submit button state
  result = {'correct': '', 'wrong': ''}; // holds the correct and incorrect ans for a question set/ displaySet
  ariaResult = '';
  constructor(
    private questionDataService: QuestionDataService,
    private milestoneService: MilestoneService
  ) { } // subcribed to questionDataService and milestoneService

  ngOnInit() {
    this.getQuestionData();
    this.questionDataService.currentIndex.subscribe(indexVal => this.displayIndex = indexVal);
  }

  /*
  ** get the question data from service
  */
  getQuestionData(): void {
    this.questions = this.questionDataService.getQuestionData();
    this.displaySet = this.questions[this.displayIndex];
  }

  /*
  ** check if the selected answer is correct or not and set respective variables.
  ** This method is just an alternative to fetching currently selected radio when submit is clicked.
  */
  checkAns(idx) {
    if (this.displaySet['a'] === this.displaySet['o'][idx] ) {
      this.isCorrectAns = true;
    } else {
      this.isCorrectAns = false;
    }
    this.disableSubmit = false;
  }

  /*
  ** decide if an answer is correct
  */
  authenticateAns() {
    if (this.isCorrectAns) {
      this.ariaResult = 'correct answer';
      this.result.correct = this.displaySet['a']; // set correct answer. Used for marking green in answers
      setTimeout(() => this.markCorrect(), 3000);
    } else {
      this.ariaResult = 'wrong answer';
      this.retryCount++;
      const wrong  = this.correctAns;
      this.result.wrong = wrong;
      this.correctAns = null; // remove the selection so that previously selected answer does not remain selected in next set of question
      if (this.retryCount > 1) {
        this.result.wrong = wrong; // set incorrect answer. Used for marking red in answers
        // alert('Not correct, here is the correct answer');
        this.correctAns = this.displaySet['a'];
        this.result.correct = this.displaySet['a'];
        setTimeout(() => this.markCorrect(), 3000);
      } else {
        // alert('Oops! Give it another try');
      }
    }
    this.disableSubmit = true;
  }

  /*
  ** if everyting is correct in a given set, move to next set of question
  */
  markCorrect () {
    this.displayIndex ++; // advance the question array index
    this.correctAnsCount ++; // increment the correct answer count
    this.setMilestone(this.correctAnsCount);

    // advance displayIndex  but only if its not last set of question
    if ( this.questions.length !== this.displayIndex  ) {
      this.questionDataService.changeIndex(this.displayIndex);
      this.displaySet = this.questions[this.displayIndex];
      this.retryCount = 0;
      this.correctAns = null;

      // reset selection of last answer
      this.result.correct = '';
      this.result.wrong = '';
      this.ariaResult = '';
    }

  }

  /*
  ** set the milestone depending upon number of correct answers
  ** This method calls milestoneService method changeMilestone, which sets currentMilestone
  ** currentMilestone is subscribed by other components like lock and pagination components
  */
  setMilestone (pCorrectAnsCount) {
    // clear 1st milestone upon completion of first two answers
    // clear 2nd milestone upon completion of next three answers ie 5th ans
    // clear 3rd  milestone upon completion of next three answers ie 8th ans
    if (pCorrectAnsCount === 2) {
      this.milestoneService.changeMilestone(1);
    }
    if (pCorrectAnsCount === 5) {
      this.milestoneService.changeMilestone(2);
    }
    if (pCorrectAnsCount === 8) {
      this.milestoneService.changeMilestone(3);
    }
    if (pCorrectAnsCount === 0) {
      this.milestoneService.changeMilestone(0);
    }
  }

   /*
  ** reset everything.
  */
  reset() {
    this.displayIndex = 0;
    this.questionDataService.changeIndex(this.displayIndex);
    this.displaySet = this.questions[this.displayIndex]; // dont need to call everytime. ned to check
    this.retryCount = 0;
    this.setMilestone(0);
    this.correctAns = null;
    this.disableSubmit = true;
    // reset selection of last answer
    this.result.correct = '';
    this.result.wrong = '';
    this.ariaResult = '';
  }

}


