import { Component, OnInit } from '@angular/core';
import { QuestionDataService } from './../question-data.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

  constructor(private questionDataService: QuestionDataService) { }
  questions = [];
  displayIndex = 0;
  // displaySet = [];
  ngOnInit() {
    this.questionDataService.currentIndex.subscribe(indexVal => this.displayIndex = indexVal);
    this.getQuestionData();
  }

  getQuestionData(): void {
    this.questions = this.questionDataService.getQuestionData();
    // this.displaySet = this.questions[this.displayIndex];
  }

}
