/*
 Milestone service will provide current milestone, which will be changed by answers componenent from time to time as answers get completed
 A component subscribing to this service will get the current milestone and can change there status accordingly
*/
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MilestoneService {

  private curMilestoneSource = new BehaviorSubject(0);
  currentMilestone = this.curMilestoneSource.asObservable();

  constructor() { }

  changeMilestone(milestoneNumber: number) {
    this.curMilestoneSource.next(milestoneNumber);

  }

}
